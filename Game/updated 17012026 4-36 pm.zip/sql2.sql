-- Add deletion flags
ALTER TABLE `games` ADD `is_deleted` TINYINT DEFAULT 0;
ALTER TABLE `tickets` ADD `is_deleted` TINYINT DEFAULT 0;
ALTER TABLE `wins` ADD `is_deleted` TINYINT DEFAULT 0;

-- Create player_tickets table for multiple tickets
CREATE TABLE IF NOT EXISTS `player_tickets` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `player_email` VARCHAR(100) NOT NULL,
  `game_id` INT(11) NOT NULL,
  `ticket_codes` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `player_email` (`player_email`),
  KEY `game_id` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;