-- Drop existing tables if needed
DROP TABLE IF EXISTS `tickets`;
DROP TABLE IF EXISTS `games`;

-- Create games table with patterns enabled
CREATE TABLE `games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_code` varchar(10) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `status` enum('waiting','started','ended') DEFAULT 'waiting',
  `current_number` int(11) DEFAULT NULL,
  `called_numbers` text DEFAULT '[]',
  `patterns_enabled` text DEFAULT '["top_line","middle_line","bottom_line","corners","full_house"]',
  `auto_call_speed` int(11) DEFAULT 3000,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `started_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_code` (`game_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create tickets table with proper structure
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_code` varchar(20) NOT NULL,
  `game_id` int(11) NOT NULL,
  `player_name` varchar(100) DEFAULT NULL,
  `player_email` varchar(100) DEFAULT NULL,
  `numbers` text NOT NULL,
  `purchase_status` enum('available','sold','used') DEFAULT 'available',
  `purchased_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_code` (`ticket_code`),
  KEY `game_id` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample game
INSERT INTO `games` (`game_code`, `game_name`, `status`) VALUES 
('TAM123', 'Friday Night Tambola', 'waiting');