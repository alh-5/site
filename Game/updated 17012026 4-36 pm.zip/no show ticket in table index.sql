-- Example query to release unpaid tickets after 30 minutes
UPDATE tickets 
SET purchase_status = 'available', 
    player_name = NULL, 
    player_email = NULL, 
    phone = NULL,
    purchased_at = NULL
WHERE purchase_status = 'pending' 
  AND purchased_at < NOW() - INTERVAL 30 MINUTE;