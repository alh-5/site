<?php
session_start();
require_once 'config.php';

// Check if admin is logged in and session is valid
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Check session timeout
checkSessionTimeout();

// Check if password has changed
checkPasswordChanged();

// Handle logout - FIXED to redirect to index.php
if(isset($_GET['logout'])) {
    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
    
    // Redirect to index.php
    header('Location: index.php');
    exit;
}

// Check if admin is logged in
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Handle logout
if(isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}

// Handle actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch($action) {
        case 'create_game':
            $game_code = strtoupper(substr(md5(uniqid()), 0, 6));
            $game_name = $_POST['game_name'];
            $patterns = [
                'top_line' => isset($_POST['top_line']),
                'bottom_line' => isset($_POST['bottom_line']),
                'corners' => isset($_POST['corners']),
                'middle_line' => isset($_POST['middle_line']),
                'full_house' => isset($_POST['full_house'])
            ];
            $prizes = [
                'top_line' => floatval($_POST['prize_top_line'] ?? 100),
                'bottom_line' => floatval($_POST['prize_bottom_line'] ?? 100),
                'corners' => floatval($_POST['prize_corners'] ?? 200),
                'middle_line' => floatval($_POST['prize_middle_line'] ?? 100),
                'full_house' => floatval($_POST['prize_full_house'] ?? 500)
            ];
            $auto_call_delay = intval($_POST['auto_call_delay']);
            
            $stmt = $conn->prepare("INSERT INTO games (game_code, game_name, patterns_enabled, pattern_prizes, auto_call_delay) VALUES (?, ?, ?, ?, ?)");
            $patterns_json = json_encode($patterns);
            $prizes_json = json_encode($prizes);
            $stmt->bind_param("ssssi", $game_code, $game_name, $patterns_json, $prizes_json, $auto_call_delay);
            $stmt->execute();
            break;
            
        case 'start_game':
            $game_id = $_POST['game_id'];
            $conn->query("UPDATE games SET status = 'started', started_at = NOW() WHERE id = $game_id");
            break;
            
        case 'end_game':
            $game_id = $_POST['game_id'];
            $conn->query("UPDATE games SET status = 'ended', ended_at = NOW() WHERE id = $game_id");
            break;
            
        case 'call_number':
            $game_id = $_POST['game_id'];
            $result = $conn->query("SELECT called_numbers FROM games WHERE id = $game_id");
            $game = $result->fetch_assoc();
            $called = json_decode($game['called_numbers'] ?? '[]', true);
            
            // Generate unique number
            $all_numbers = range(1, 90);
            $available = array_diff($all_numbers, $called);
            
            if(count($available) > 0) {
                $new_number = $available[array_rand($available)];
                $called[] = $new_number;
                $called_json = json_encode($called);
                
                $conn->query("UPDATE games SET current_number = $new_number, called_numbers = '$called_json' WHERE id = $game_id");
                
                // Announce to all players
                announceNumber($game_id, $new_number);
            }
            break;
            
        case 'generate_tickets':
            $game_id = $_POST['game_id'];
            $count = intval($_POST['ticket_count']);
            
            for($i = 0; $i < $count; $i++) {
                $ticket_code = 'TKT' . strtoupper(substr(md5(uniqid()), 0, 8));
                $numbers = generateTicketNumbers();
                $stmt = $conn->prepare("INSERT INTO tickets (ticket_code, game_id, numbers) VALUES (?, ?, ?)");
                $stmt->bind_param("sis", $ticket_code, $game_id, $numbers);
                $stmt->execute();
            }
            break;
            
        case 'update_game_settings':
            $game_id = $_POST['game_id'];
            $patterns = [
                'top_line' => isset($_POST['top_line']),
                'bottom_line' => isset($_POST['bottom_line']),
                'corners' => isset($_POST['corners']),
                'middle_line' => isset($_POST['middle_line']),
                'full_house' => isset($_POST['full_house'])
            ];
            $prizes = [
                'top_line' => floatval($_POST['prize_top_line'] ?? 100),
                'bottom_line' => floatval($_POST['prize_bottom_line'] ?? 100),
                'corners' => floatval($_POST['prize_corners'] ?? 200),
                'middle_line' => floatval($_POST['prize_middle_line'] ?? 100),
                'full_house' => floatval($_POST['prize_full_house'] ?? 500)
            ];
            $auto_call_delay = intval($_POST['auto_call_delay']);
            
            $stmt = $conn->prepare("UPDATE games SET patterns_enabled = ?, pattern_prizes = ?, auto_call_delay = ? WHERE id = ?");
            $patterns_json = json_encode($patterns);
            $prizes_json = json_encode($prizes);
            $stmt->bind_param("ssii", $patterns_json, $prizes_json, $auto_call_delay, $game_id);
            $stmt->execute();
            break;
            
        case 'save_system_settings':
            // In a real system, you'd save these to a settings table
            $_SESSION['system_settings'] = [
                'site_title' => $_POST['site_title'],
                'ticket_price' => floatval($_POST['ticket_price']),
                'default_auto_call' => intval($_POST['default_auto_call'])
            ];
            break;
            
        case 'declare_winner':
            $game_id = $_POST['game_id'];
            $ticket_code = $_POST['ticket_code'];
            $pattern = $_POST['pattern'];
            $prize = floatval($_POST['prize']);
            $player_name = $_POST['player_name'];
            
            $stmt = $conn->prepare("INSERT INTO wins (game_id, ticket_code, player_name, pattern_type, prize_amount) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("isssd", $game_id, $ticket_code, $player_name, $pattern, $prize);
            $stmt->execute();
            
            // Announce winner
            announceWinner($game_id, $player_name, $pattern, $prize);
            break;
            
        // Add new delete actions
        case 'delete_all_tickets':
            // Optional: Add confirmation before deletion
            $confirm = $_POST['confirm'] ?? '';
            if($confirm === 'YES') {
                $conn->query("TRUNCATE TABLE tickets");
            }
            break;
            
        case 'delete_all_games':
            $confirm = $_POST['confirm'] ?? '';
            if($confirm === 'YES') {
                // First delete related tickets and winners
                $conn->query("DELETE FROM tickets WHERE 1");
                $conn->query("DELETE FROM wins WHERE 1");
                $conn->query("DELETE FROM games WHERE 1");
            }
            break;
            
        case 'delete_all_winners':
            $confirm = $_POST['confirm'] ?? '';
            if($confirm === 'YES') {
                $conn->query("TRUNCATE TABLE wins");
            }
            break;
            
        case 'delete_single_game':
            $game_id = $_POST['game_id'] ?? 0;
            $confirm = $_POST['confirm'] ?? '';
            if($confirm === 'YES' && $game_id > 0) {
                // Delete related tickets and winners first
                $conn->query("DELETE FROM tickets WHERE game_id = $game_id");
                $conn->query("DELETE FROM wins WHERE game_id = $game_id");
                $conn->query("DELETE FROM games WHERE id = $game_id");
            }
            break;
            
        case 'delete_single_ticket':
            $ticket_id = $_POST['ticket_id'] ?? 0;
            $confirm = $_POST['confirm'] ?? '';
            if($confirm === 'YES' && $ticket_id > 0) {
                $conn->query("DELETE FROM tickets WHERE id = $ticket_id");
            }
            break;
            
        case 'delete_single_winner':
            $winner_id = $_POST['winner_id'] ?? 0;
            $confirm = $_POST['confirm'] ?? '';
            if($confirm === 'YES' && $winner_id > 0) {
                $conn->query("DELETE FROM wins WHERE id = $winner_id");
            }
            break;
    }
    
    header("Location: admin_panel.php");
    exit;
}

// Function to announce number to all players (you can implement WebSocket or use a polling system)
function announceNumber($game_id, $number) {
    global $conn;
    // This is a placeholder - in a real app, use WebSockets
    file_put_contents("announcements/game_$game_id.txt", "NUMBER:$number");
}

// Function to announce winner
function announceWinner($game_id, $player_name, $pattern, $prize) {
    global $conn;
    // This is a placeholder - in a real app, use WebSockets
    file_put_contents("announcements/game_{$game_id}_winner.txt", "WINNER:$player_name:$pattern:$prize");
}

// Ticket generation function (5 numbers in each row, 15 total)
function generateTicketNumbers() {
    $ticket = array_fill(0, 27, 0); // 3 rows x 9 columns
    
    // Column ranges (1-9, 10-19, 20-29, 30-39, 40-49, 50-59, 60-69, 70-79, 80-90)
    $columnRanges = [
        [1, 9],    // Col 0: 1-9
        [10, 19],  // Col 1: 10-19
        [20, 29],  // Col 2: 20-29
        [30, 39],  // Col 3: 30-39
        [40, 49],  // Col 4: 40-49
        [50, 59],  // Col 5: 50-59
        [60, 69],  // Col 6: 60-69
        [70, 79],  // Col 7: 70-79
        [80, 90]   // Col 8: 80-90
    ];
    
    // Step 1: First ensure each column has at least 1 number
    for($col = 0; $col < 9; $col++) {
        $rows = [0, 1, 2];
        shuffle($rows);
        $row = $rows[0]; // Pick random row for this column
        
        $min = $columnRanges[$col][0];
        $max = $columnRanges[$col][1];
        $ticket[$row * 9 + $col] = rand($min, $max);
    }
    
    // Step 2: Count numbers in each row
    $rowCounts = [0, 0, 0];
    for($row = 0; $row < 3; $row++) {
        for($col = 0; $col < 9; $col++) {
            if($ticket[$row * 9 + $col] > 0) {
                $rowCounts[$row]++;
            }
        }
    }
    
    // Step 3: Add remaining 6 numbers (2 per row to make 5 each)
    $numbersToAdd = 6;
    $attempts = 0;
    
    while($numbersToAdd > 0 && $attempts < 100) {
        for($row = 0; $row < 3 && $numbersToAdd > 0; $row++) {
            if($rowCounts[$row] < 5) {
                // Find empty columns in this row
                $emptyCols = [];
                for($col = 0; $col < 9; $col++) {
                    if($ticket[$row * 9 + $col] == 0) {
                        // Check if column already has 3 numbers
                        $colCount = 0;
                        for($r = 0; $r < 3; $r++) {
                            if($ticket[$r * 9 + $col] > 0) {
                                $colCount++;
                            }
                        }
                        if($colCount < 3) {
                            $emptyCols[] = $col;
                        }
                    }
                }
                
                if(count($emptyCols) > 0) {
                    $col = $emptyCols[array_rand($emptyCols)];
                    $min = $columnRanges[$col][0];
                    $max = $columnRanges[$col][1];
                    
                    // Generate unique number for this column
                    $existingNumbers = [];
                    for($r = 0; $r < 3; $r++) {
                        if($ticket[$r * 9 + $col] > 0) {
                            $existingNumbers[] = $ticket[$r * 9 + $col];
                        }
                    }
                    
                    // Try to find a unique number
                    $found = false;
                    for($tries = 0; $tries < 20; $tries++) {
                        $number = rand($min, $max);
                        if(!in_array($number, $existingNumbers)) {
                            $ticket[$row * 9 + $col] = $number;
                            $rowCounts[$row]++;
                            $numbersToAdd--;
                            $found = true;
                            break;
                        }
                    }
                    
                    // If no unique number found, use any number
                    if(!$found && count($existingNumbers) < 3) {
                        $number = rand($min, $max);
                        $ticket[$row * 9 + $col] = $number;
                        $rowCounts[$row]++;
                        $numbersToAdd--;
                    }
                }
            }
        }
        $attempts++;
    }
    
    // Step 4: Ensure each row has exactly 5 numbers
    for($row = 0; $row < 3; $row++) {
        // Count numbers in this row
        $rowNumbers = [];
        for($col = 0; $col < 9; $col++) {
            if($ticket[$row * 9 + $col] > 0) {
                $rowNumbers[] = $col;
            }
        }
        
        // Add numbers if less than 5
        while(count($rowNumbers) < 5) {
            // Find columns that can accept more numbers
            $availableCols = [];
            for($col = 0; $col < 9; $col++) {
                if($ticket[$row * 9 + $col] == 0) {
                    // Check column count
                    $colCount = 0;
                    for($r = 0; $r < 3; $r++) {
                        if($ticket[$r * 9 + $col] > 0) {
                            $colCount++;
                        }
                    }
                    if($colCount < 3) {
                        $availableCols[] = $col;
                    }
                }
            }
            
            if(count($availableCols) > 0) {
                $col = $availableCols[array_rand($availableCols)];
                $min = $columnRanges[$col][0];
                $max = $columnRanges[$col][1];
                
                // Get existing numbers in this column
                $existingNumbers = [];
                for($r = 0; $r < 3; $r++) {
                    if($ticket[$r * 9 + $col] > 0) {
                        $existingNumbers[] = $ticket[$r * 9 + $col];
                    }
                }
                
                // Find a number
                $number = rand($min, $max);
                $tries = 0;
                while(in_array($number, $existingNumbers) && $tries < 10) {
                    $number = rand($min, $max);
                    $tries++;
                }
                
                $ticket[$row * 9 + $col] = $number;
                $rowNumbers[] = $col;
            } else {
                break;
            }
        }
        
        // Remove numbers if more than 5
        while(count($rowNumbers) > 5) {
            $col = $rowNumbers[array_rand($rowNumbers)];
            
            // Check if removing breaks column rule
            $colCount = 0;
            for($r = 0; $r < 3; $r++) {
                if($ticket[$r * 9 + $col] > 0) {
                    $colCount++;
                }
            }
            
            if($colCount > 1) {
                $ticket[$row * 9 + $col] = 0;
                $rowNumbers = array_values(array_filter($rowNumbers, function($c) use ($col) {
                    return $c != $col;
                }));
            }
        }
    }
    
    // Step 5: Sort columns in ascending order
    for($col = 0; $col < 9; $col++) {
        $columnVals = [];
        $rowsWithVals = [];
        
        for($row = 0; $row < 3; $row++) {
            if($ticket[$row * 9 + $col] > 0) {
                $columnVals[] = $ticket[$row * 9 + $col];
                $rowsWithVals[] = $row;
            }
        }
        
        if(count($columnVals) > 1) {
            sort($columnVals);
            for($i = 0; $i < count($columnVals); $i++) {
                $ticket[$rowsWithVals[$i] * 9 + $col] = $columnVals[$i];
            }
        }
    }
    
    // Step 6: Validate final ticket
    $totalNumbers = 0;
    $rowTotals = [0, 0, 0];
    $colTotals = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    
    for($row = 0; $row < 3; $row++) {
        for($col = 0; $col < 9; $col++) {
            if($ticket[$row * 9 + $col] > 0) {
                $totalNumbers++;
                $rowTotals[$row]++;
                $colTotals[$col]++;
                
                // Validate number range
                $min = $columnRanges[$col][0];
                $max = $columnRanges[$col][1];
                $num = $ticket[$row * 9 + $col];
                if($num < $min || $num > $max) {
                    // Adjust to valid range
                    $ticket[$row * 9 + $col] = rand($min, $max);
                }
            }
        }
    }
    
    // Final check: Ensure exactly 15 numbers
    if($totalNumbers != 15) {
        // Use simpler generation as fallback
        return generateSimpleTicket();
    }
    
    return json_encode($ticket);
}

// Fallback function for ticket generation
function generateSimpleTicket() {
    $ticket = array_fill(0, 27, 0);
    
    // Select 15 random positions
    $positions = range(0, 26);
    shuffle($positions);
    $selectedPositions = array_slice($positions, 0, 15);
    
    // Column ranges
    $columnRanges = [
        [1, 9], [10, 19], [20, 29], [30, 39], [40, 49],
        [50, 59], [60, 69], [70, 79], [80, 90]
    ];
    
    // Assign numbers to positions
    foreach($selectedPositions as $pos) {
        $col = $pos % 9;
        $min = $columnRanges[$col][0];
        $max = $columnRanges[$col][1];
        $ticket[$pos] = rand($min, $max);
    }
    
    return json_encode($ticket);
}

// Get data
$games = $conn->query("SELECT * FROM games ORDER BY created_at DESC");
$total_tickets = $conn->query("SELECT COUNT(*) as count FROM tickets")->fetch_assoc()['count'];
$sold_tickets = $conn->query("SELECT COUNT(*) as count FROM tickets WHERE purchase_status = 'sold'")->fetch_assoc()['count'];
$active_games = $conn->query("SELECT COUNT(*) as count FROM games WHERE status = 'started'")->fetch_assoc()['count'];

// System settings
$system_settings = $_SESSION['system_settings'] ?? [
    'site_title' => 'DB Tambola',
    'ticket_price' => 50,
    'default_auto_call' => 5
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - DB Tambola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #2c3e50 0%, #4a6491 100%);
            color: white;
            padding: 0;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-left: 4px solid transparent;
            transition: all 0.3s;
        }
        .sidebar-menu .nav-link:hover,
        .sidebar-menu .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left-color: #4CAF50;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 15px;
        }
        .game-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-waiting { background: #fff3cd; color: #856404; }
        .status-started { background: #d4edda; color: #155724; }
        .status-ended { background: #f8d7da; color: #721c24; }
        .btn-action {
            padding: 5px 10px;
            font-size: 0.85rem;
            margin: 2px;
        }
        .prize-input {
            width: 80px;
            display: inline-block;
            margin-left: 10px;
        }
        .delete-btn {
            background: linear-gradient(45deg, #dc3545, #c82333);
            border: none;
            color: white;
            transition: all 0.3s;
        }
        .delete-btn:hover {
            background: linear-gradient(45deg, #c82333, #bd2130);
            transform: scale(1.05);
        }
        .danger-zone {
            border: 2px solid #dc3545;
            background: #fff5f5;
            border-radius: 10px;
            padding: 20px;
            margin-top: 30px;
        }
        .danger-zone h4 {
            color: #dc3545;
            border-bottom: 2px solid #dc3545;
            padding-bottom: 10px;
        }
        .ticket-preview {
            background: white;
            border: 2px solid #333;
            border-radius: 5px;
            padding: 10px;
            font-family: monospace;
            font-weight: bold;
        }
        .ticket-cell {
            width: 40px;
            height: 40px;
            border: 1px solid #ccc;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 2px;
        }
        .ticket-cell.filled {
            background: #f0f8ff;
            border-color: #4CAF50;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
            }
            .sidebar-menu {
                display: flex;
                overflow-x: auto;
            }
            .sidebar-menu .nav-link {
                white-space: nowrap;
                border-left: none;
                border-bottom: 3px solid transparent;
            }
            .sidebar-menu .nav-link.active {
                border-bottom-color: #4CAF50;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">
                <i class="fas fa-user-shield me-2"></i>Admin Panel
            </h4>
            <small class="text-muted">Welcome, <?php echo $_SESSION['admin_username']; ?></small>
        </div>
        
        <div class="sidebar-menu">
            <nav class="nav flex-column">
                <a class="nav-link active" href="#dashboard">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a class="nav-link" href="#games">
                    <i class="fas fa-gamepad me-2"></i> Games
                </a>
                <a class="nav-link" href="#tickets">
                    <i class="fas fa-ticket-alt me-2"></i> Tickets
                </a>
                <a class="nav-link" href="#winners">
                    <i class="fas fa-trophy me-2"></i> Winners
                </a>
                <a class="nav-link" href="#settings">
                    <i class="fas fa-cog me-2"></i> Settings
                </a>
                <a class="nav-link text-danger" href="?logout=1">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Dashboard -->
        <div id="dashboard" class="content-section">
            <h2 class="mb-4"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h2>
            
            <!-- Stats -->
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-primary text-white">
                            <i class="fas fa-gamepad"></i>
                        </div>
                        <h5>Total Games</h5>
                        <h2><?php echo $games->num_rows; ?></h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-success text-white">
                            <i class="fas fa-play-circle"></i>
                        </div>
                        <h5>Active Games</h5>
                        <h2><?php echo $active_games; ?></h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-info text-white">
                            <i class="fas fa-ticket-alt"></i>
                        </div>
                        <h5>Total Tickets</h5>
                        <h2><?php echo $total_tickets; ?></h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-warning text-white">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <h5>Tickets Sold</h5>
                        <h2><?php echo $sold_tickets; ?></h2>
                    </div>
                </div>
            </div>

            <!-- Create Game -->
            <div class="stat-card">
                <h4 class="mb-3"><i class="fas fa-plus-circle me-2"></i>Create New Game</h4>
                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="create_game">
                    <div class="col-md-4">
                        <input type="text" name="game_name" class="form-control" 
                               placeholder="Game Name" required>
                    </div>
                    <div class="col-md-3">
                        <input type="number" name="auto_call_delay" class="form-control" 
                               min="1" max="30" value="5" placeholder="Auto-call delay (sec)">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-plus me-2"></i>Create Game
                        </button>
                    </div>
                    
                    <!-- Patterns with Prizes -->
                    <div class="col-12 mt-3">
                        <label class="form-label fw-bold">Patterns & Prizes:</label>
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="top_line" id="top_line" checked>
                                    <label class="form-check-label" for="top_line">Top Line</label>
                                    <input type="number" name="prize_top_line" class="form-control prize-input mt-1" value="100" min="0">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="bottom_line" id="bottom_line" checked>
                                    <label class="form-check-label" for="bottom_line">Bottom Line</label>
                                    <input type="number" name="prize_bottom_line" class="form-control prize-input mt-1" value="100" min="0">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="corners" id="corners" checked>
                                    <label class="form-check-label" for="corners">Corners</label>
                                    <input type="number" name="prize_corners" class="form-control prize-input mt-1" value="200" min="0">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="middle_line" id="middle_line" checked>
                                    <label class="form-check-label" for="middle_line">Middle Line</label>
                                    <input type="number" name="prize_middle_line" class="form-control prize-input mt-1" value="100" min="0">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="full_house" id="full_house" checked>
                                    <label class="form-check-label" for="full_house">Full House</label>
                                    <input type="number" name="prize_full_house" class="form-control prize-input mt-1" value="500" min="0">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Games Management -->
        <div id="games" class="content-section d-none">
            <h2 class="mb-4"><i class="fas fa-gamepad me-2"></i>Games Management</h2>
            
            <div class="stat-card">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Game Name</th>
                                <th>Code</th>
                                <th>Status</th>
                                <th>Numbers</th>
                                <th>Players</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $games->data_seek(0);
                            while($game = $games->fetch_assoc()): 
                                $called = json_decode($game['called_numbers'] ?? '[]', true);
                                $called_count = count($called);
                                $players_count = $conn->query("SELECT COUNT(*) as count FROM tickets WHERE game_id = {$game['id']} AND purchase_status = 'sold'")->fetch_assoc()['count'];
                            ?>
                            <tr>
                                <td><?php echo $game['id']; ?></td>
                                <td><?php echo htmlspecialchars($game['game_name']); ?></td>
                                <td><code><?php echo $game['game_code']; ?></code></td>
                                <td>
                                    <span class="game-status status-<?php echo $game['status']; ?>">
                                        <?php echo strtoupper($game['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $called_count; ?>/90</td>
                                <td><?php echo $players_count; ?></td>
                                <td>
                                    <div class="btn-group">
                                        <?php if($game['status'] == 'waiting'): ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="action" value="start_game">
                                                <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
                                                <button type="submit" class="btn btn-success btn-sm btn-action">
                                                    <i class="fas fa-play"></i> Start
                                                </button>
                                            </form>
                                            <button class="btn btn-info btn-sm btn-action" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#generateTicketsModal"
                                                    data-game-id="<?php echo $game['id']; ?>">
                                                <i class="fas fa-ticket-alt"></i> Tickets
                                            </button>
                                        <?php elseif($game['status'] == 'started'): ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="action" value="call_number">
                                                <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
                                                <button type="submit" class="btn btn-warning btn-sm btn-action">
                                                    <i class="fas fa-bullhorn"></i> Call
                                                </button>
                                            </form>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="action" value="end_game">
                                                <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm btn-action" 
                                                        onclick="return confirm('End this game?')">
                                                    <i class="fas fa-stop"></i> End
                                                </button>
                                            </form>
                                            <button class="btn btn-primary btn-sm btn-action"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#declareWinnerModal"
                                                    data-game-id="<?php echo $game['id']; ?>"
                                                    data-game-name="<?php echo htmlspecialchars($game['game_name']); ?>"
                                                    data-patterns='<?php echo $game['patterns_enabled']; ?>'
                                                    data-prizes='<?php echo $game['pattern_prizes']; ?>'>
                                                <i class="fas fa-trophy"></i> Declare
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn btn-secondary btn-sm btn-action"
                                                data-bs-toggle="modal"
                                                data-bs-target="#gameSettingsModal"
                                                data-game-id="<?php echo $game['id']; ?>"
                                                data-game-name="<?php echo htmlspecialchars($game['game_name']); ?>"
                                                data-patterns='<?php echo $game['patterns_enabled']; ?>'
                                                data-prizes='<?php echo $game['pattern_prizes']; ?>'
                                                data-delay="<?php echo $game['auto_call_delay']; ?>">
                                            <i class="fas fa-cog"></i> Settings
                                        </button>
                                        <a href="game.php?code=<?php echo $game['game_code']; ?>" 
                                           target="_blank" class="btn btn-primary btn-sm btn-action">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button class="btn btn-danger btn-sm btn-action delete-game-btn"
                                                data-game-id="<?php echo $game['id']; ?>"
                                                data-game-name="<?php echo htmlspecialchars($game['game_name']); ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Danger Zone: Delete All Games -->
                <div class="danger-zone mt-4">
                    <h4><i class="fas fa-exclamation-triangle me-2"></i>Danger Zone</h4>
                    <p class="text-muted">These actions cannot be undone. All data will be permanently deleted.</p>
                    <button class="btn btn-danger delete-all-btn" 
                            data-type="games"
                            data-message="This will delete ALL games, along with their tickets and winners. This action cannot be undone!">
                        <i class="fas fa-trash me-2"></i>Delete All Games
                    </button>
                </div>
            </div>
        </div>

        <!-- Tickets -->
        <div id="tickets" class="content-section d-none">
            <h2 class="mb-4"><i class="fas fa-ticket-alt me-2"></i>Tickets Management</h2>
            
            <div class="stat-card">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Ticket Code</th>
                                <th>Game</th>
                                <th>Player</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Purchased</th>
                                <th>Numbers</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $tickets_query = "SELECT t.*, g.game_name FROM tickets t 
                                             LEFT JOIN games g ON t.game_id = g.id 
                                             ORDER BY t.purchased_at DESC LIMIT 100";
                            $tickets_result = $conn->query($tickets_query);
                            while($ticket = $tickets_result->fetch_assoc()):
                                $numbers = json_decode($ticket['numbers'], true);
                                $number_count = count(array_filter($numbers, function($n) { return $n > 0; }));
                            ?>
                            <tr>
                                <td><code><?php echo $ticket['ticket_code']; ?></code></td>
                                <td><?php echo $ticket['game_name'] ?? 'N/A'; ?></td>
                                <td><?php echo $ticket['player_name'] ?? 'Not Sold'; ?></td>
                                <td><?php echo $ticket['player_email'] ?? 'N/A'; ?></td>
                                <td>
                                    <?php if($ticket['purchase_status'] == 'sold'): ?>
                                        <span class="badge bg-success">Sold</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Available</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $ticket['purchased_at'] ?? '-'; ?></td>
                                <td><?php echo $number_count; ?> numbers</td>
                                <td>
                                    <button class="btn btn-info btn-sm view-ticket-btn"
                                            data-ticket-code="<?php echo $ticket['ticket_code']; ?>"
                                            data-numbers='<?php echo $ticket['numbers']; ?>'>
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-danger btn-sm delete-ticket-btn"
                                            data-ticket-id="<?php echo $ticket['id']; ?>"
                                            data-ticket-code="<?php echo $ticket['ticket_code']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Danger Zone: Delete All Tickets -->
                <div class="danger-zone mt-4">
                    <h4><i class="fas fa-exclamation-triangle me-2"></i>Danger Zone</h4>
                    <p class="text-muted">These actions cannot be undone. All tickets will be permanently deleted.</p>
                    <button class="btn btn-danger delete-all-btn" 
                            data-type="tickets"
                            data-message="This will delete ALL tickets. This action cannot be undone!">
                        <i class="fas fa-trash me-2"></i>Delete All Tickets
                    </button>
                </div>
            </div>
        </div>

        <!-- Winners -->
        <div id="winners" class="content-section d-none">
            <h2 class="mb-4"><i class="fas fa-trophy me-2"></i>Winners</h2>
            
            <div class="stat-card">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Game</th>
                                <th>Player</th>
                                <th>Ticket</th>
                                <th>Pattern</th>
                                <th>Prize</th>
                                <th>Claimed At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $winners_query = "SELECT w.*, g.game_name FROM wins w 
                                             LEFT JOIN games g ON w.game_id = g.id 
                                             ORDER BY w.claimed_at DESC";
                            $winners_result = $conn->query($winners_query);
                            while($winner = $winners_result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $winner['game_name']; ?></td>
                                <td><strong><?php echo $winner['player_name']; ?></strong></td>
                                <td><code><?php echo $winner['ticket_code']; ?></code></td>
                                <td>
                                    <span class="badge bg-info">
                                        <?php 
                                        $pattern_names = [
                                            'top_line' => 'Top Line',
                                            'bottom_line' => 'Bottom Line',
                                            'corners' => 'Corners',
                                            'middle_line' => 'Middle Line',
                                            'full_house' => 'Full House'
                                        ];
                                        echo $pattern_names[$winner['pattern_type']] ?? ucfirst($winner['pattern_type']);
                                        ?>
                                    </span>
                                </td>
                                <td><strong>₹<?php echo number_format($winner['prize_amount'], 2); ?></strong></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($winner['claimed_at'])); ?></td>
                                <td>
                                    <button class="btn btn-danger btn-sm delete-winner-btn"
                                            data-winner-id="<?php echo $winner['id']; ?>"
                                            data-player-name="<?php echo htmlspecialchars($winner['player_name']); ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if($winners_result->num_rows == 0): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    <i class="fas fa-trophy fa-2x mb-3"></i>
                                    <p>No winners declared yet</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Danger Zone: Delete All Winners -->
                <div class="danger-zone mt-4">
                    <h4><i class="fas fa-exclamation-triangle me-2"></i>Danger Zone</h4>
                    <p class="text-muted">These actions cannot be undone. All winners records will be permanently deleted.</p>
                    <button class="btn btn-danger delete-all-btn" 
                            data-type="winners"
                            data-message="This will delete ALL winners records. This action cannot be undone!">
                        <i class="fas fa-trash me-2"></i>Delete All Winners
                    </button>
                </div>
            </div>
        </div>

        <!-- Settings -->
        <div id="settings" class="content-section d-none">
            <h2 class="mb-4"><i class="fas fa-cog me-2"></i>System Settings</h2>
            
            <div class="stat-card">
                <form method="POST" id="systemSettingsForm">
                    <input type="hidden" name="action" value="save_system_settings">
                    
                    <div class="mb-3">
                        <label class="form-label">Site Title</label>
                        <input type="text" name="site_title" class="form-control" 
                               value="<?php echo htmlspecialchars($system_settings['site_title']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Default Ticket Price (₹)</label>
                        <input type="number" name="ticket_price" class="form-control" 
                               value="<?php echo $system_settings['ticket_price']; ?>" min="1">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Default Auto-call Delay (seconds)</label>
                        <input type="number" name="default_auto_call" class="form-control" 
                               value="<?php echo $system_settings['default_auto_call']; ?>" min="1" max="30">
                        <div class="form-text">Default delay between auto-called numbers</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Default Pattern Prizes (₹)</label>
                        <div class="row">
                            <div class="col-md-2">
                                <label class="form-label small">Top Line</label>
                                <input type="number" name="default_prize_top_line" class="form-control" value="100" min="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small">Bottom Line</label>
                                <input type="number" name="default_prize_bottom_line" class="form-control" value="100" min="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small">Corners</label>
                                <input type="number" name="default_prize_corners" class="form-control" value="200" min="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small">Middle Line</label>
                                <input type="number" name="default_prize_middle_line" class="form-control" value="100" min="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small">Full House</label>
                                <input type="number" name="default_prize_full_house" class="form-control" value="500" min="0">
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Settings
                    </button>
                </form>
                
                <!-- Danger Zone: Delete Everything -->
                <div class="danger-zone mt-5">
                    <h4><i class="fas fa-skull-crossbones me-2"></i>Nuclear Option</h4>
                    <p class="text-muted">This will delete ALL data from the system including games, tickets, and winners.</p>
                    <button class="btn btn-dark delete-all-btn" 
                            data-type="everything"
                            data-message="WARNING: This will delete EVERYTHING - all games, tickets, and winners. This is irreversible!">
                        <i class="fas fa-bomb me-2"></i>Delete Everything
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Generate Tickets Modal -->
    <div class="modal fade" id="generateTicketsModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Generate Tickets</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="generate_tickets">
                    <input type="hidden" id="modalGameId" name="game_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Number of tickets</label>
                            <input type="number" name="ticket_count" class="form-control" 
                                   min="1" max="1000" value="10" required>
                            <div class="form-text">Each ticket will have 15 random numbers (5 per row)</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Generate</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Game Settings Modal -->
    <div class="modal fade" id="gameSettingsModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Game Settings</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_game_settings">
                    <input type="hidden" id="settingsGameId" name="game_id">
                    <div class="modal-body">
                        <h5 id="gameNameDisplay" class="mb-3"></h5>
                        
                        <div class="mb-3">
                            <label class="form-label">Auto-call Delay (seconds)</label>
                            <input type="number" id="settingsDelay" name="auto_call_delay" 
                                   class="form-control" min="1" max="30" required>
                            <div class="form-text">Delay between auto-called numbers (0 to disable)</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Pattern Settings:</label>
                            <div class="row" id="patternSettings">
                                <!-- Will be populated by JavaScript -->
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Declare Winner Modal -->
    <div class="modal fade" id="declareWinnerModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Declare Winner</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="declare_winner">
                    <input type="hidden" id="winnerGameId" name="game_id">
                    <div class="modal-body">
                        <h6 id="winnerGameName" class="mb-3"></h6>
                        
                        <div class="mb-3">
                            <label class="form-label">Ticket Code</label>
                            <input type="text" name="ticket_code" class="form-control" 
                                   placeholder="Enter ticket code" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Player Name</label>
                            <input type="text" name="player_name" class="form-control" 
                                   placeholder="Enter player name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Winning Pattern</label>
                            <select name="pattern" class="form-control" id="patternSelect" required>
                                <option value="">Select Pattern</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Prize Amount (₹)</label>
                            <input type="number" name="prize" class="form-control" 
                                   id="prizeAmount" required min="0" step="0.01">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Declare Winner</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Ticket Modal -->
    <div class="modal fade" id="viewTicketModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ticket Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6 id="ticketCodeDisplay" class="mb-3"></h6>
                    <div class="ticket-preview" id="ticketView">
                        <!-- Ticket will be displayed here -->
                    </div>
                    <div class="mt-3">
                        <p><strong>Numbers:</strong> <span id="ticketNumbersList"></span></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteConfirmationModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Deletion</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="deleteForm">
                    <input type="hidden" name="action" id="deleteAction">
                    <input type="hidden" name="confirm" value="YES">
                    <input type="hidden" name="game_id" id="deleteGameId">
                    <input type="hidden" name="ticket_id" id="deleteTicketId">
                    <input type="hidden" name="winner_id" id="deleteWinnerId">
                    <div class="modal-body">
                        <div class="alert alert-danger">
                            <h5 id="deleteTitle"></h5>
                            <p id="deleteMessage"></p>
                            <p class="mb-0"><strong>This action cannot be undone!</strong></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Type <code>YES</code> to confirm deletion:</label>
                            <input type="text" class="form-control" id="confirmationInput" 
                                   placeholder="Enter YES to confirm" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger" id="confirmDeleteBtn" disabled>
                            <i class="fas fa-trash me-2"></i>Delete
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Show dashboard by default
            showSection('dashboard');
            
            // Sidebar click handlers
            $('.sidebar-menu .nav-link').click(function(e) {
                e.preventDefault();
                $('.sidebar-menu .nav-link').removeClass('active');
                $(this).addClass('active');
                
                const target = $(this).attr('href').substring(1);
                showSection(target);
            });
            
            // Modal handlers
            $('#generateTicketsModal').on('show.bs.modal', function(e) {
                const button = $(e.relatedTarget);
                const gameId = button.data('game-id');
                $('#modalGameId').val(gameId);
            });
            
            $('#gameSettingsModal').on('show.bs.modal', function(e) {
                const button = $(e.relatedTarget);
                const gameId = button.data('game-id');
                const gameName = button.data('game-name');
                const patterns = JSON.parse(button.data('patterns'));
                const prizes = JSON.parse(button.data('prizes'));
                const delay = button.data('delay');
                
                $('#settingsGameId').val(gameId);
                $('#gameNameDisplay').text('Settings for: ' + gameName);
                $('#settingsDelay').val(delay);
                
                // Pattern settings
                const patternDefs = {
                    'top_line': 'Top Line',
                    'bottom_line': 'Bottom Line',
                    'corners': 'Corners',
                    'middle_line': 'Middle Line',
                    'full_house': 'Full House'
                };
                
                let patternHtml = '';
                for (const [pattern, name] of Object.entries(patternDefs)) {
                    const isEnabled = patterns[pattern] || false;
                    const prize = prizes[pattern] || 0;
                    
                    patternHtml += `
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" 
                                           name="${pattern}" id="set${pattern}" ${isEnabled ? 'checked' : ''}>
                                    <label class="form-check-label fw-bold" for="set${pattern}">${name}</label>
                                </div>
                                <div class="mt-2">
                                    <label class="form-label small">Prize Amount (₹)</label>
                                    <input type="number" name="prize_${pattern}" 
                                           class="form-control" value="${prize}" min="0">
                                </div>
                            </div>
                        </div>
                    </div>`;
                }
                $('#patternSettings').html(patternHtml);
            });
            
            $('#declareWinnerModal').on('show.bs.modal', function(e) {
                const button = $(e.relatedTarget);
                const gameId = button.data('game-id');
                const gameName = button.data('game-name');
                const patterns = JSON.parse(button.data('patterns'));
                const prizes = JSON.parse(button.data('prizes'));
                
                $('#winnerGameId').val(gameId);
                $('#winnerGameName').text('Game: ' + gameName);
                
                // Populate pattern select
                const patternSelect = $('#patternSelect');
                patternSelect.empty();
                patternSelect.append('<option value="">Select Pattern</option>');
                
                const patternDefs = {
                    'top_line': 'Top Line',
                    'bottom_line': 'Bottom Line',
                    'corners': 'Corners',
                    'middle_line': 'Middle Line',
                    'full_house': 'Full House'
                };
                
                for (const [pattern, name] of Object.entries(patternDefs)) {
                    if (patterns[pattern]) {
                        const prize = prizes[pattern] || 0;
                        patternSelect.append(`<option value="${pattern}" data-prize="${prize}">${name} (₹${prize})</option>`);
                    }
                }
                
                // Update prize amount when pattern is selected
                patternSelect.change(function() {
                    const selected = $(this).find(':selected');
                    const prize = selected.data('prize') || 0;
                    $('#prizeAmount').val(prize);
                });
            });
            
            // View ticket modal
            $('.view-ticket-btn').click(function() {
                const ticketCode = $(this).data('ticket-code');
                const numbers = JSON.parse($(this).data('numbers'));
                
                $('#ticketCodeDisplay').text('Ticket Code: ' + ticketCode);
                displayTicket(numbers, '#ticketView');
                
                // List numbers
                const numberList = numbers.filter(n => n > 0).sort((a, b) => a - b);
                $('#ticketNumbersList').text(numberList.join(', '));
                
                $('#viewTicketModal').modal('show');
            });
            
            // System settings form
            $('#systemSettingsForm').submit(function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'admin_panel.php',
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function() {
                        alert('Settings saved successfully!');
                    }
                });
            });
            
            // Delete confirmation logic
            $('#confirmationInput').on('input', function() {
                const inputVal = $(this).val().toUpperCase();
                $('#confirmDeleteBtn').prop('disabled', inputVal !== 'YES');
            });
            
            // Delete all buttons
            $('.delete-all-btn').click(function() {
                const type = $(this).data('type');
                const message = $(this).data('message');
                
                let title = '';
                let action = '';
                
                switch(type) {
                    case 'games':
                        title = 'Delete All Games';
                        action = 'delete_all_games';
                        break;
                    case 'tickets':
                        title = 'Delete All Tickets';
                        action = 'delete_all_tickets';
                        break;
                    case 'winners':
                        title = 'Delete All Winners';
                        action = 'delete_all_winners';
                        break;
                    case 'everything':
                        title = 'Delete Everything';
                        action = 'delete_all_games'; // This will cascade
                        break;
                }
                
                $('#deleteTitle').text(title);
                $('#deleteMessage').text(message);
                $('#deleteAction').val(action);
                $('#confirmationInput').val('');
                $('#confirmDeleteBtn').prop('disabled', true);
                
                $('#deleteForm').off('submit').submit(function(e) {
                    if(type === 'everything') {
                        // Delete everything in sequence
                        e.preventDefault();
                        deleteEverything();
                        return false;
                    }
                });
                
                $('#deleteConfirmationModal').modal('show');
            });
            
            // Delete single game
            $('.delete-game-btn').click(function() {
                const gameId = $(this).data('game-id');
                const gameName = $(this).data('game-name');
                
                $('#deleteTitle').text('Delete Game');
                $('#deleteMessage').text(`This will delete the game "${gameName}" and all associated tickets and winners. This action cannot be undone!`);
                $('#deleteAction').val('delete_single_game');
                $('#deleteGameId').val(gameId);
                $('#confirmationInput').val('');
                $('#confirmDeleteBtn').prop('disabled', true);
                
                $('#deleteConfirmationModal').modal('show');
            });
            
            // Delete single ticket
            $('.delete-ticket-btn').click(function() {
                const ticketId = $(this).data('ticket-id');
                const ticketCode = $(this).data('ticket-code');
                
                $('#deleteTitle').text('Delete Ticket');
                $('#deleteMessage').text(`This will delete ticket: ${ticketCode}. This action cannot be undone!`);
                $('#deleteAction').val('delete_single_ticket');
                $('#deleteTicketId').val(ticketId);
                $('#confirmationInput').val('');
                $('#confirmDeleteBtn').prop('disabled', true);
                
                $('#deleteConfirmationModal').modal('show');
            });
            
            // Delete single winner
            $('.delete-winner-btn').click(function() {
                const winnerId = $(this).data('winner-id');
                const playerName = $(this).data('player-name');
                
                $('#deleteTitle').text('Delete Winner Record');
                $('#deleteMessage').text(`This will delete the winner record for "${playerName}". This action cannot be undone!`);
                $('#deleteAction').val('delete_single_winner');
                $('#deleteWinnerId').val(winnerId);
                $('#confirmationInput').val('');
                $('#confirmDeleteBtn').prop('disabled', true);
                
                $('#deleteConfirmationModal').modal('show');
            });
        });
        
        function showSection(sectionId) {
            $('.content-section').addClass('d-none');
            $('#' + sectionId).removeClass('d-none');
        }
        
        function deleteEverything() {
            // Show loading state
            $('#confirmDeleteBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Deleting...');
            
            // Delete in sequence: winners -> tickets -> games
            $.ajax({
                url: 'admin_panel.php',
                method: 'POST',
                data: {
                    action: 'delete_all_winners',
                    confirm: 'YES'
                },
                success: function() {
                    $.ajax({
                        url: 'admin_panel.php',
                        method: 'POST',
                        data: {
                            action: 'delete_all_tickets',
                            confirm: 'YES'
                        },
                        success: function() {
                            $.ajax({
                                url: 'admin_panel.php',
                                method: 'POST',
                                data: {
                                    action: 'delete_all_games',
                                    confirm: 'YES'
                                },
                                success: function() {
                                    $('#deleteConfirmationModal').modal('hide');
                                    alert('All data has been deleted successfully!');
                                    location.reload();
                                },
                                error: function() {
                                    alert('Error deleting games');
                                    $('#deleteConfirmationModal').modal('hide');
                                }
                            });
                        },
                        error: function() {
                            alert('Error deleting tickets');
                            $('#deleteConfirmationModal').modal('hide');
                        }
                    });
                },
                error: function() {
                    alert('Error deleting winners');
                    $('#deleteConfirmationModal').modal('hide');
                }
            });
        }
        
        function displayTicket(numbers, selector) {
            let html = '<div class="text-center">';
            
            // Header
            html += '<div class="mb-2"><strong>Tambola Ticket</strong></div>';
            
            // Ticket grid
            for(let row = 0; row < 3; row++) {
                html += '<div class="row mb-1 justify-content-center">';
                for(let col = 0; col < 9; col++) {
                    const index = row * 9 + col;
                    const num = numbers[index];
                    if(num > 0) {
                        html += `<div class="ticket-cell filled">${num}</div>`;
                    } else {
                        html += '<div class="ticket-cell">&nbsp;</div>';
                    }
                }
                html += '</div>';
            }
            
            // Footer with row counts
            html += '<div class="mt-2 small text-muted">';
            for(let row = 0; row < 3; row++) {
                let count = 0;
                for(let col = 0; col < 9; col++) {
                    if(numbers[row * 9 + col] > 0) count++;
                }
                html += `Row ${row + 1}: ${count} numbers | `;
            }
            html += 'Total: 15 numbers';
            html += '</div>';
            
            html += '</div>';
            $(selector).html(html);
        }
    </script>
</body>
</html>