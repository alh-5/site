-- Drop existing tables if they exist
DROP TABLE IF EXISTS `wins`;
DROP TABLE IF EXISTS `tickets`;
DROP TABLE IF EXISTS `games`;

-- Create games table
CREATE TABLE `games` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `game_code` VARCHAR(10) NOT NULL,
  `game_name` VARCHAR(100) NOT NULL,
  `status` ENUM('waiting','started','ended') DEFAULT 'waiting',
  `current_number` INT(11) DEFAULT NULL,
  `called_numbers` TEXT DEFAULT '[]',
  `patterns_enabled` TEXT DEFAULT '{"top_line":true,"bottom_line":true,"corners":true,"middle_line":true,"full_house":true}',
  `pattern_prizes` TEXT DEFAULT '{"top_line":100,"bottom_line":100,"corners":200,"middle_line":100,"full_house":500}',
  `auto_call_delay` INT DEFAULT 5,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `started_at` DATETIME DEFAULT NULL,
  `ended_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_code` (`game_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create tickets table
CREATE TABLE `tickets` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `ticket_code` VARCHAR(20) NOT NULL,
  `game_id` INT(11) NOT NULL,
  `player_name` VARCHAR(100) DEFAULT NULL,
  `player_email` VARCHAR(100) DEFAULT NULL,
  `numbers` TEXT NOT NULL,
  `purchase_status` ENUM('available','sold','used') DEFAULT 'available',
  `purchased_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_code` (`ticket_code`),
  KEY `game_id` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create wins table for tracking pattern winners
CREATE TABLE `wins` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `game_id` INT(11) NOT NULL,
  `ticket_code` VARCHAR(20) NOT NULL,
  `player_name` VARCHAR(100) NOT NULL,
  `pattern_type` VARCHAR(20) NOT NULL,
  `prize_amount` DECIMAL(10,2) NOT NULL,
  `claimed_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `game_id` (`game_id`),
  KEY `ticket_code` (`ticket_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create admin_users table
CREATE TABLE `admin_users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin (password: 1908)
INSERT INTO `admin_users` (`username`, `password`) 
VALUES ('dbareh', '$2y$10$6B8z3qW9mY5xLpRkFvG8DeNtQrS2uV4wXyZ7aBcDfGhJkLmNoPqRsT');