<?php
session_start();
require_once 'config.php';

// If already logged in, redirect to admin panel
if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    // Check if password has changed since login
    if(isset($_SESSION['admin_password_hash']) && 
       $_SESSION['admin_password_hash'] !== md5(ADMIN_PASSWORD)) {
        // Password changed, force logout
        session_destroy();
        header('Location: admin_login.php?msg=password_changed');
        exit;
    }
    header('Location: admin_panel.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if(verifyAdmin($username, $password)) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_password_hash'] = md5(ADMIN_PASSWORD); // Store hash for verification
        
        // Also store login timestamp for session timeout
        $_SESSION['admin_login_time'] = time();
        
        header('Location: admin_panel.php');
        exit;
    } else {
        $error = "Invalid credentials!";
    }
}

// Check for messages
$message = '';
if(isset($_GET['msg'])) {
    switch($_GET['msg']) {
        case 'password_changed':
            $message = "Password has been changed. Please login again.";
            break;
        case 'session_expired':
            $message = "Session expired. Please login again.";
            break;
        case 'logged_out':
            $message = "Successfully logged out.";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - DB Tambola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }
        .message-box {
            animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2 class="text-center mb-4">
            <i class="fas fa-user-shield"></i> Admin Login
        </h2>
        
        <?php if($message): ?>
            <div class="alert alert-info message-box">
                <i class="fas fa-info-circle me-2"></i><?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" required 
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                       autocomplete="username">
            </div>
            <div class="mb-4">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required 
                       autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
        
        <div class="text-center mt-3">
            <a href="index.php" class="text-decoration-none">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
        </div>
        
        <div class="mt-4 text-center text-muted small">
            <i class="fas fa-lock"></i> Secure Admin Access
        </div>
    </div>
</body>
</html>