CREATE TABLE IF NOT EXISTS tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    ticket_code VARCHAR(50) UNIQUE NOT NULL,
    numbers TEXT NOT NULL,
    purchase_status ENUM('available', 'sold') DEFAULT 'available',
    player_name VARCHAR(100),
    player_email VARCHAR(100),
    phone VARCHAR(20),
    purchased_at DATETIME,
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
);